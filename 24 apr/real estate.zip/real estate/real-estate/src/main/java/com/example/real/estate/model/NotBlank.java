package com.example.real.estate.model;

public @interface NotBlank {

    String message();

}
