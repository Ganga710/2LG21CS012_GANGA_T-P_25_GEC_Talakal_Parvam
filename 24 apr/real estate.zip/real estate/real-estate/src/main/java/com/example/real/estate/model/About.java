package com.example.real.estate.model;

public class About {
    
}
