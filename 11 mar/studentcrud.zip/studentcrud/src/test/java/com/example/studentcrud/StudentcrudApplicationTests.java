package com.example.studentcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
