package com.example.real.estate.service;
import com.example.realestate.model.Property;
import com.example.realestate.repository.PropertyRepository;
import org.springframework.stereotype.Service;
import java.util.List;

public class PropertServiceImple implements PropertyService {

    private final PropertyRepository propertyRepository;

    public PropertyServiceImpl(PropertyRepository propertyRepository) {
        this.propertyRepository = propertyRepository;
    }

    @Override
    public void saveProperty(Property property) {
        propertyRepository.save(property);
    }

    @Override
    public List<Property> getAllProperties() {
        return propertyRepository.findAll();
    }
}
