package com.example.real.estate.controller;

public class UserRegistrationDto {

    public String getFullname() {
        
        throw new UnsupportedOperationException("Unimplemented method 'getFullname'");
    }

}
