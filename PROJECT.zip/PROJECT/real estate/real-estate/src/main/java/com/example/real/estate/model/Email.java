package com.example.real.estate.model;

public @interface Email {

    String message();

}
