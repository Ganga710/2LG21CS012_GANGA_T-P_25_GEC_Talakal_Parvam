package com.example.real.estate.controller;

public @interface Valid {

}
