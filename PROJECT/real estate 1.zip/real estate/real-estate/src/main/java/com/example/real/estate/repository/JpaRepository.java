package com.example.real.estate.repository;

public class JpaRepository<T1, T2> {

}
