package com.example.real.estate.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.real.estate.model.Agent;
import com.example.real.estate.repository.AgentRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class AgentService {

    @Autowired
    private AgentRepository agentRepository;

    public String saveAgent(Agent agent) {
        // Get the current date and time
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedNow = now.format(formatter);

        // Set audit fields
        agent.setCreated_on(formattedNow); // Assuming you have a 'created_on' field in your model
        agent.setCreated_by("System User"); // Set the user who is creating the record
        agent.setModified_on(formattedNow); // Assuming you have a 'modified_on' field
        agent.setModified_by("System User"); // Set the modifier
        agent.setDelete_status("Active"); // Assuming you have a 'delete_status' field

        // Save the admin object to the database
        agentRepository.save(agent);

        return "Agent data saved successfully"; // Success message
    }
}
