package com.example.real.estate.service;

public class AboutService {
    
}
