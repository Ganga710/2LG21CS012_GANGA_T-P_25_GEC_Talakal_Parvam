package com.example.real.estate.repository;

public class AboutRepository {
    
}
