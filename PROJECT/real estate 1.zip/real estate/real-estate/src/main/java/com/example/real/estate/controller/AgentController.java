package com.example.real.estate.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import com.example.real.estate.model.Agent;
import com.example.real.estate.repository.AgentRepository;
import com.example.real.estate.service.AgentService;


@Controller
@RequestMapping("/agent")
public class AgentController {

    @Autowired
    private AgentService agentService;

    // Display the login form and pass an empty Admin object to Thymeleaf
    @GetMapping("/login")
    public String showLoginPage(Model model) {
        model.addAttribute("agent", new Agent()); // Pass an empty Admin object
        return "login"; // Returns templates/login.html
    }

    // Handle form submission
    @PostMapping("/login") // This matches the form action in the HTML
    public String submitAgent(@ModelAttribute Agent agent) {
        // Call the service to save admin data to the database
        agentService.saveAgent(agent); // Save the Admin entity to the database

        
        return "redirect:/addproperty"; // Redirect to dashboard
    }

    @Autowired
    private AgentRepository agentRepository;

    @PostMapping("/agent/login")
    public String login(@RequestParam String username,
            @RequestParam String emailid,
            @RequestParam String password) {
        Agent agent = new Agent();
        agent.setUsername(username);
        agent.setEmailid(emailid);
        agent.setPassword(password);

        agentRepository.save(agent); // This should now work

        return "success"; // your confirmation view
    }

}