import java.util.Arrays;

public class array {
    public static void main(String[] arg){
        int[][]numbers= new int[4][4];
        numbers[0][0]=1;
        System.out.println(Arrays.deepToString(numbers));
    }
}
