
public class Trial {
    public static void main(String[]arg){
        String  message =" Hel\"lo\""+"!! ";
        System.out.println(message.trim());
        System.out.println(message);

    }
    
}
